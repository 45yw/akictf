/*=======================================================================*
 * 算術式の処理のためのヘッダ                                            *
 *=======================================================================*/

#ifndef _EXP_H_INCLUDED_
#define _EXP_H_INCLUDED_

/*----- エラー処理 -----*/

void *exit_error(const char *str);

/*----- 算術式のデータ構造 -----*/

#include "tree.h"

/*
 * e->node  … 演算子
 * e->left  … 左の部分算術式へのポインタ
 * e->right … 右の部分算術式へのポインタ
 */

typedef Tree *  Exp;

/*----- 算術式の基本関数 -----*/

Exp make0_exp(char c);                          /* 定数や変数の生成 */
Exp make1_exp(char c, Exp e);                   /* 単項の算術式の生成 */
Exp make2_exp(char c, Exp e1, Exp e2);          /* ２項の算術式の生成 */

void copy_exp(const Exp src, Exp *dst);         /* 算術式の複製 */
void delete_exp(Exp *ep);                       /* 算術式の消去 */

Exp read_exp(void);                             /* 算術式の読み込み */
void show_exp(const Exp e);                     /* 算術式の表示 */

int eval_exp(const Exp e);                      /* 算術式の値の計算 */

/*----- 算術式の変形関数 -----*/

void rotate_left_exp(Exp *ep);                  /* 左回転 */
void rotate_right_exp(Exp *ep);                 /* 右回転 */

void assoc_left_exp(Exp *ep);                   /* 括弧を左にくくり直す */
void push_neg_exp(Exp *ep);                     /* 負号を内側へ移動する */
void dist_prod_exp(Exp *ep);                    /* 積を和に分配する */

#endif /* _EXP_H_INCLUDED_ */
