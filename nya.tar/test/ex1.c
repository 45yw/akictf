/*=======================================================================*
 * 木構造と数式処理 課題１ (２分木のデータ構造)                          *
 *=======================================================================*/

#include <stdio.h>
#include "tree.h"   /* ２分木の基本関数用のヘッダを読み込む */

/* まず tree.c の branch(), leaf() を実装し */
/* 残りの課題の答えをこのファイルに書き込む */

#define dump_i(x) printf("%s : %d\n", #x, x);

int height(Tree *t, int h){
  int l, r;
  if(t == NULL){
	return 0;
  }
  l = height(t->left, h);
  r = height(t->right, h);
  return (l > r) ? (l + 1) : (r + 1);
}

/*
void show_size(void){
  int a = sizeof(Tree);
  int b = sizeof(char);
  int c = sizeof(Tree *);
  printf("%d %d %d\n", a, b, c);
}
*/

int is_symmetric(const Tree *t1, const Tree *t2){
  if (t1 == NULL) {
    return (t2 == NULL);
  }
  else {
    return (t2 != NULL  &&
            t1->node == t2->node  &&
            equal_tree(t1->left,  t2->right)  &&
            equal_tree(t1->right, t2->left));
  }
}

Tree *mirror(const Tree *t){
  if (t == NULL) {
    return NULL;
  }
  else {
    return branch(t->node, copy_tree(t->right), copy_tree(t->left));
  }
}

int main(void) {
  Tree *t1, *t2, *t3, *t4, *t5;
  //Tree *t1, *t2, *t3, *t4, *t5;
  t1 = leaf('c');
  t2 = leaf('a');
  t3 = branch('+', leaf('b'), leaf('1'));
  t4 = branch('+', t2, t3);
  t5 = branch('*', t4, t1);
  /*t4 = leaf('z');
	t5 = branch('*', t3, t4);
  */
  //dump_i(height(t3, 0));
  printf("%d\n", height(t1, 0));
  printf("%d\n", height(t2, 0));
  printf("%d\n", height(t3, 0));
  printf("%d\n", height(t4, 0));
  printf("%d\n", height(t5, 0));
  show_tree(t1);
  show_tree(t2);
  show_tree(t3);
  show_tree(t4);
  show_tree(t5);
  /*
	show_size();
	show_node(t1);
	show_node(t2);
	show_node(t3);
  */
  return 0;
}
