/*=======================================================================*
 * 木構造と数式処理 課題２ (数式データの操作)                            *
 *=======================================================================*/

#include <stdio.h>
#include <ctype.h>
#include "exp.h"   /* 算術式操作用のヘッダを読み込む */

/* exp.c の関数を実装しながら，このファイルで動作確認する */
/* プログラムをよく読み，内容を理解してから手を加えること */

/*----- 算術式の括弧を左にくくり直す変形 -----*/

/*
 * (E1+(E2+E3)) → ((E1+E2)+E3)
 * (E1*(E2*E3)) → ((E1*E2)*E3)
 */

void assoc_left(Exp *ep) {
  rotate_left_exp(ep);
}

/*----- 算術式のデータ操作 -----*/

int main(void) {
  Exp e0 = NULL, e1 = NULL;
  int val, c;
  while (1) {

    /* 読み込み */
    e0 = read_exp();
    if (e0 == NULL) { break; }   /* 入力の終わりに達したら抜ける */

    /* 値の計算，変形 */
    val = eval_exp(e0);
    copy_exp(e0, &e1);
    assoc_left(&e1);

    /* 表示 */
    printf("show:  "); show_exp(e0);
    printf("eval:  "); printf("%d\n", val);
    printf("assoc: "); show_exp(e1);
    putchar('\n');

    /*削除 */
    delete_exp(&e0);
    delete_exp(&e1);

    /* 区切りの処理 */
    c = getchar();
    if (! isspace(c)) { exit_error("*** separator not found ***\n"); }
  }
  return 0;
}
