/*=======================================================================*
 * 算術式の操作                                                          *
 *=======================================================================*/

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "exp.h"

/*==============================*
 * エラー処理                   *
 *==============================*/

void *exit_error(const char *str) {
  fprintf(stderr, "*** %s ***\n", str);
  exit(EXIT_FAILURE);
}

/*==============================*
 * 算術式の基本関数             *
 *==============================*/

/*----- 算術式の生成と複製と削除 -----*/

Exp make0_exp(char c)                  { return leaf(c); }
Exp make1_exp(char c, const Exp e)     { return branch(c, e, NULL); }
Exp make2_exp(char c, const Exp e1, const Exp e2)
{ return branch(c, e1, e2); }
void copy_exp(const Exp src, Exp *dst) { *dst = copy_tree(src); }
void delete_exp(Exp *ep)               { free_tree(*ep); *ep = NULL; }

/*----- 算術式の読み込み -----*/
Exp read_exp(void) {
  int c;
  Exp l = NULL, r = NULL;   /* 左部分式，右部分式 */
  char op;                  /* 演算子 */
  c = getchar();
  if (c == EOF) {
	return NULL;
  }
  
  if (isalnum(c)) {
    return leaf(c);
  }
  else{
    if (c != '(') {
	  exit_error("expression not found");
	}
    l = read_exp();
    c = getchar();
    if (c != '+' && c != '*') {
	  exit_error("operator not found");
	}
    op = (char)c;
    r = read_exp();
    c = getchar();
    if (c != ')') {
	  exit_error("closing parenthesis not found");
	}
    return leaf(c);
  }
}

/*
  void show_tree_sub(const Exp e) {
  if (e != NULL) {
  putchar('(');
  show_tree_sub(e->left);
  }

  putchar(e->node);

  if(e != NULL){
  putchar(')');
  show_tree_sub(e->right);
  }
  }
*/

/*----- 算術式の表示 -----*/

void show_exp(const Exp e) {
  if (e != NULL) {
    putchar('(');
	show_exp(e->left);
  }

  putchar(e->node);

  if(e != NULL){
	putchar(')');
    show_exp(e->right);
  }
  putchar('\n');
}

int eval_exp(const Exp e) {
  Exp n;
  if(isalpha(e->node)){
	return 1;
  }

  else if(isdigit(e->node)){
	return e->node - '0';
  }

  else{
	switch (e->node) {
	case '+':
	  n = e->left + e->right;
	  return  eval_exp(n);
	  break;
	case '*':
	  n = e->left * e->right;
	  return eval_exp(n);
	  break;
	}
	eval_exp(e->node);
  }
  return 0;
}

/*==============================*
 * 算術式の変形                 *
 *==============================*/

/*----- 回転 -----*/

/*
 *     %              @
 *    / \   左回転   / \
 *  E1   @    →    %   E3
 *      / \        / \
 *    E2   E3    E1   E2
 */

void rotate_left_exp(Exp *ep) {
  Exp ep2;
  ep2 = (*)ep->right;
  ep->right = ep->left;
  (*)ep->left = ep2;
  ep = ep2;
}

void rotate_right_exp(Exp *ep) {
  Exp ep2;
  *ep2 = ep->left;
  ep->left = ep->right;
  ep->right = *ep2;
  ep = ep2;
  
}

/*----- 括弧のくくり直し -----*/

/*
 * (E1+(E2+E3)) → ((E1+E2)+E3)
 * (E1*(E2*E3)) → ((E1*E2)*E3)
 */

void assoc_left_exp(Exp *ep) {
  Exp e = *ep, r = NULL;             /* 式全体と右部分式 */
  char c;
  if (e != NULL) {
    assoc_left_exp(&(e->left));      /* 左の部分式を変形 */
    assoc_left_exp(&(e->right));     /* 右の部分式を変形 */
    c = e->node;
    r = e->right;
    if ((c == '+' || c == '*') && r != NULL && c == r->node) {
      /* 括弧を左にくくり直せる */
      rotate_left_exp(ep);           /* １度だけ左にくくり直す */
      assoc_left_exp(ep);            /* 変形後の式全体を再変形 */
    }
  }
}

/*----- 積の和に対する分配 -----*/

/*
 * (E1*(E2+E3)) → ((E1*E2)+(E1*E3))
 * ((E1+E2)*E3) → ((E1*E3)+(E2*E3))
 */

void dist_prod_exp(Exp *ep) {
  Exp ep2, ep3;

  if(ep->node != '*'){
	dist_prod_exp(ep->right);
	dist_prod_exp(ep->left);
  }
  else{
	//(x+y)*z
	if(ep->left != '+'){
	  copy_exp(ep2, ep->left);
	  rotate_right_exp(ep);
	  ep->left =  make2_exp('*', ep->left, ep2);
	  dist_prod_exp(ep->left);
	  dist_prod_exp(ep->right);
	}

	//z*(x+y)
	else{
	  copy_exp(ep3, ep->right);
	  rotate_left_exp(ep);
	  ep->right =  make2_exp('*', ep->right, ep3);
	  dist_prod_exp(ep->left);
	  dist_prod_exp(ep->right);
	}
  }
}

