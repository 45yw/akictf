/*=======================================================================*
 * 木構造と数式処理 課題３ (数式の変形)                                  *
 *=======================================================================*/

#include <stdio.h>
#include <ctype.h>
#include "exp.h"   /* 算術式操作用のヘッダを読み込む */

/* exp.c の関数を実装しながら，このファイルで動作確認する */
/* プログラムをよく読み，内容を理解してから手を加えること */

/*----- 算術式の変形 -----*/

int main(void) {
  Exp e0 = NULL, e1 = NULL, e2 = NULL;
  int val0, val1, c;
  while (1) {

    /* 読み込み */
    e0 = read_exp();
    if (e0 == NULL) { break; }   /* 入力の終わりに達したら抜ける */

    /* 値の計算，変形 */   /* (push,) dist, assoc の順に注意 */
    val0 = eval_exp(e0);
    copy_exp(e0, &e1); dist_prod_exp(&e1);
    copy_exp(e1, &e2); assoc_left_exp(&e2);
    val1 = eval_exp(e2);

    /* 表示 */
    printf("show:  "); show_exp(e0);
    printf("eval:  "); printf("%d\n", val0);
    printf("dist:  "); show_exp(e1);
    printf("assoc: "); show_exp(e2);
    printf("eval:  "); printf("%d\n", val1);
    putchar('\n');

    /* 削除 */
    delete_exp(&e0);
    delete_exp(&e1);
    delete_exp(&e2);

    /* 区切りの処理 */
    c = getchar();
    if (! isspace(c)) { exit_error("*** separator not found ***\n"); }
  }
  return 0;
}
