/*=======================================================================*
 * ２分木のデータ構造と基本関数のためのヘッダ                            *
 *=======================================================================*/

#ifndef _TREE_H_INCLUDED_
#define _TREE_H_INCLUDED_

/*----- ２分木のデータ構造 -----*/

typedef struct _tree {
  char           node;                            /* 節のデータ (1文字) */
  struct _tree  *left;                            /* 左の子へのポインタ */
  struct _tree  *right;                           /* 右の子へのポインタ */
} Tree;

/*----- ２分木の基本関数 -----*/

Tree *branch(char x, Tree *l, Tree *r);           /* 枝の生成 */
Tree *leaf(char x);                               /* 葉の生成 */

void show_tree(const Tree *t);                    /* 木全体の表示 */
void show_node(const Tree *t);                    /* 節の詳細表示 */

int equal_tree(const Tree *t1, const Tree *t2);   /* 木の等しさの判定 */

Tree *copy_tree(const Tree *t);                   /* 木の複製 */
void free_tree(Tree *t);                          /* 木の消去 */

#endif /* _TREE_H_INCLUDED_ */
